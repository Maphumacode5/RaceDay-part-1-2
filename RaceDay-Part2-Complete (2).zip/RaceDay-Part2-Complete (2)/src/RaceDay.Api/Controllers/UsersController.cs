using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.DTOs;

namespace RaceDay.Api.Controllers;

[ApiController]
[Route("api/users")]
public class UsersController : ControllerBase
{
    private readonly RaceDayDbContext _db;
    public UsersController(RaceDayDbContext db) => _db=db;

    [HttpGet("me")]
    public async Task<IActionResult> Me()
    {
        var id = HttpContext.Session.GetInt32("UserId");
        if (id is null) return Unauthorized();
        var u = await _db.Users.FindAsync(id.Value);
        return u is null ? Unauthorized() : Ok(new UserResponse(u.UserId,u.FirstName,u.LastName,u.Email,u.Role,u.PhoneNumber,u.ProfilePictureUrl));
    }

    [HttpPut("me")]
    public async Task<IActionResult> Update(UpdateProfileRequest request)
    {
        var id = HttpContext.Session.GetInt32("UserId");
        if (id is null) return Unauthorized();
        var u = await _db.Users.FindAsync(id.Value);
        if (u is null) return Unauthorized();
        u.FirstName=request.FirstName.Trim(); u.LastName=request.LastName.Trim(); u.PhoneNumber=request.PhoneNumber?.Trim();
        await _db.SaveChangesAsync();
        return Ok(new UserResponse(u.UserId,u.FirstName,u.LastName,u.Email,u.Role,u.PhoneNumber,u.ProfilePictureUrl));
    }

    [HttpPut("me/profile-picture")]
    [Consumes("multipart/form-data")]
    public async Task<IActionResult> ProfilePicture(IFormFile image)
    {
        var id = HttpContext.Session.GetInt32("UserId");
        if (id is null) return Unauthorized();
        if (image is null || image.Length == 0) return BadRequest(new {message="An image file is required."});
        // Part 3 will route this file through Azure Blob Storage. Part 2 deliberately
        // keeps the database field ready without coupling the API to Azure.
        return Ok(new { message="Image received. Blob Storage integration is implemented in Part 3.", fileName=image.FileName });
    }
}
