using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.DTOs;
using RaceDay.Api.Models;

namespace RaceDay.Api.Controllers;

[ApiController]
[Route("api")]
public class EnrolmentsController : ControllerBase
{
    private readonly RaceDayDbContext _db;
    public EnrolmentsController(RaceDayDbContext db)=>_db=db;

    [HttpPost("events/{eventId:int}/enrolments")]
    public async Task<IActionResult> Enrol(int eventId, EnrolmentRequest request)
    {
        if(!IsRole("Participant"))return Forbid();
        var e=await _db.Events.FindAsync(eventId);if(e is null)return NotFound();
        var c=await _db.Categories.FindAsync(request.CategoryId);if(c is null||c.EventId!=eventId)return BadRequest(new{message="Category does not belong to this event."});
        if(await _db.Enrolments.AnyAsync(x=>x.ParticipantId==UserId()&&x.EventId==eventId))return Conflict(new{message="Already enrolled in this event."});
        var en=new Enrolment{ParticipantId=UserId(),EventId=eventId,CategoryId=c.CategoryId,Status="Pending"};
        _db.Enrolments.Add(en);await _db.SaveChangesAsync();
        return Created($"/api/enrolments/{en.EnrolmentId}",new{en.EnrolmentId,en.ParticipantId,en.EventId,en.CategoryId,en.EnrolmentDate,en.Status});
    }

    [HttpGet("users/me/enrolments")]
    public async Task<IActionResult> Mine()
    {
        if(!IsRole("Participant"))return Forbid();
        return Ok(await Query().Where(x=>x.ParticipantId==UserId()).OrderByDescending(x=>x.EnrolmentDate).ToListAsync());
    }

    [HttpGet("events/{eventId:int}/enrolments")]
    public async Task<IActionResult> ForEvent(int eventId)
    {
        if(!IsRole("Organiser"))return Forbid();
        var e=await _db.Events.FindAsync(eventId);if(e is null)return NotFound();if(e.OrganiserId!=UserId())return Forbid();
        return Ok(await Query().Where(x=>x.EventId==eventId).ToListAsync());
    }

    [HttpPut("enrolments/{id:int}/status")]
    public async Task<IActionResult> Status(int id, EnrolmentStatusRequest request)
    {
        if(!IsRole("Organiser"))return Forbid();
        if(request.Status is not ("Pending" or "Confirmed" or "Cancelled"))return BadRequest(new{message="Invalid status."});
        var en=await _db.Enrolments.Include(x=>x.Event).SingleOrDefaultAsync(x=>x.EnrolmentId==id);if(en is null)return NotFound();if(en.Event.OrganiserId!=UserId())return Forbid();
        en.Status=request.Status;await _db.SaveChangesAsync();
        return Ok(new{en.EnrolmentId,en.Status});
    }

    private IQueryable<EnrolmentResponse> Query()=>_db.Enrolments.AsNoTracking().Include(x=>x.Participant).Include(x=>x.Event).Include(x=>x.Category)
        .Select(x=>new EnrolmentResponse(x.EnrolmentId,x.ParticipantId,x.Participant.FirstName+" "+x.Participant.LastName,x.EventId,x.Event.Name,x.CategoryId,x.Category.Name,x.EnrolmentDate,x.Status));
    private bool IsRole(string role)=>HttpContext.Session.GetString("Role")==role&&HttpContext.Session.GetInt32("UserId") is not null;
    private int UserId()=>HttpContext.Session.GetInt32("UserId")!.Value;
}
