using System.ComponentModel.DataAnnotations;

namespace RaceDay.Api.DTOs;
public record EnrolmentRequest([property: Range(1, int.MaxValue)] int CategoryId);
public record EnrolmentStatusRequest([property: Required] string Status);
public record EnrolmentResponse(int EnrolmentId, int ParticipantId, string ParticipantName, int EventId, string EventName, int CategoryId, string CategoryName, DateTime EnrolmentDate, string Status);
